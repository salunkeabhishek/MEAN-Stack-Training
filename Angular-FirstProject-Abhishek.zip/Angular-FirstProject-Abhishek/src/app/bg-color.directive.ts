import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appBgColor]'
})
export class BgColorDirective implements OnInit{
 @Input("appBgColor") appBgColor: string;
 @Input("myBorderColor") myBorderColorI:string;
 @HostListener('mouseenter') onMouseEnter(){
  this.elementRef.nativeElement.style.backgroundColor = 'yellow';
  this.elementRef.nativeElement.style.color='black';
 }

 @HostListener('mouseleave') onMocseLeave(){
  this.elementRef.nativeElement.style.backgroundColor='red';
  this.elementRef.nativeElement.style.color='black';
 }
 constructor(private elementRef: ElementRef){
    this.appBgColor = "blue";
    this.myBorderColorI = "blue"
    elementRef.nativeElement.style.backgroundColor='red';
    elementRef.nativeElement.style.color='black';

 }
 ngOnInit(): void {
    if(this.appBgColor){
     this.elementRef.nativeElement.style.backgroundColor = this.appBgColor;
    }
    if(this.myBorderColorI){
      this.elementRef.nativeElement.style.border = this.myBorderColorI;
    }
 }
}

