import { Component, ElementRef, inject, ViewChild } from '@angular/core';
import  Products  from '../model/Products';
import  Cart  from '../model/Cart';
import { Router } from '@angular/router';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'product-display',
  standalone: false,
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})


export class ProductDisplayComponent {
   products:Products[];
   showAddToMart: boolean;
   selectedProduct: Products|null;
   cartObj: Cart|null;
   productManagementService : ProductManagementService;
   constructor (private router: Router){
    this.showAddToMart = false;
    this.productManagementService = inject(ProductManagementService);
    this.selectedProduct = null;
    this.cartObj =null;
    this.products = this.productManagementService.getAllProductsItems(); 
  };
@ViewChild('scrollTarget') scrollTarget: ElementRef | any;
addToCart(selectedProduct: Products){
  alert(selectedProduct.productName);
  this.showAddToMart = true;
  this.selectedProduct = selectedProduct;
  this.scrollToTarget();
}

sendDataFromAddToCartToPDEventHandler(cartObj:Cart|null)
{
  if(cartObj!=null)
  {
    //check pos of products from main menu to reduce the quantity. 
    var pos = this.products.findIndex(product => product.productId == cartObj.productId)
    //Update the value of Parent Menu 
    //alert("Pos" + pos + "products: " + this.products[pos].quantity + "selected Quantity" + cartObj.quantitySelected);
    if(pos>=0) {
    this.products[pos].quantity = this.products[pos].quantity -  cartObj.quantitySelected; 
    }
    //unmount the child component add to cart
    this.showAddToMart =false;
    this.selectedProduct = null;
  }
}
sendCancelDataFromAddToCartToPDEventHandler(){
  this.showAddToMart =false;
  this.selectedProduct=null;
}
 detailsEventHandler(selectedProduct: Products)
 {
  this.router.navigate(['productDetails',selectedProduct.productId])
 }
  scrollToTarget() {
    this.scrollTarget.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

}