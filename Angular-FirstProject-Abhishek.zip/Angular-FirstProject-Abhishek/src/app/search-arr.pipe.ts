import { Pipe, PipeTransform } from '@angular/core';
import { provideClientHydration } from '@angular/platform-browser';
@Pipe({
  name: 'searchArr'
})
export class SearchArrPipe implements PipeTransform {

  transform(value: any[],searchText:string="", fieldName:string=""): any[] {
    if(searchText == "" || fieldName =="")
    {
      return value;
    }
    else if(fieldName.length > 0 && searchText.length > 0){
      if(fieldName=="qunatity"){
        var filteredArr = value.filter(element =>{
          if(element.quantity == searchText){
            return element
      }})}
      else if(fieldName=="price"){
        var filteredArr = value.filter(element =>{
          if(element.price == searchText){
            return element
      }})}
      else if(fieldName=="productId"){
        var filteredArr = value.filter(element =>{
          if(element.productId == searchText){
            return element
      }})}
        else {
          var filteredArr = value.filter(element =>{
          if(element.productName.toString().toUpperCase().includes(searchText.toUpperCase())){
            return element
          }
          })}
    }
    else {
       return value;
      }
    return filteredArr;
  }

}
