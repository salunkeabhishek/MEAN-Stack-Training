import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import Products from '../model/Products';

@Component({
  selector: 'app-edit-component',
  templateUrl: './edit-component.component.html',
  styleUrls: ['./edit-component.component.css']
})
export class EditComponentComponent implements OnInit{
   @Input() modifyProduct: Products | null;
   @Output() modifyProductChange: EventEmitter<Products>;
   constructor(){
    this.modifyProduct = null;
    this.modifyProductChange = new EventEmitter<Products>();
   }

   ngOnInit(){
    if(this.modifyProduct){
      this.modifyProduct.price = 0;
    }
   }
   closeTheEditComponent(){
    
   }
}
