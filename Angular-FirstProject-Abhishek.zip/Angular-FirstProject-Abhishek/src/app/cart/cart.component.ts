import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';
import Cart from '../model/Cart';
import Products from '../model/Products';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartArr: Cart[];
  constructor(private router: Router, private cms:CartManagementService){
   this.cartArr = cms.getAllCartItems();
}
proceedToPayment(){
    this.router.navigate(['/payments'])
}
buy(product:Products){

}
saveForLater(product:Products){

}
}
