import { Injectable } from '@angular/core';
import Products from './model/Products';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor() {
    this.productsArr =[
      new Products(101, 'Iphone 13', 'Latest model with advanced features', '128 GB', 80000, 2, './assets/iphone13.jpg'),
      new Products(102, 'Iphone 14', 'Great performance and battery life', '256 GB', 70000, 2, './assets/iphone14.jpg'),
      new Products(103, 'Iphone 15', 'Affordable option with good features', '64 GB', 60000, 5, './assets/iphone15.jpg'),
     new Products(104, 'Iphone 16', 'Compact and powerful', '64 GB', 40000, 3, './assets/iphone15Pro.jpg'),
     new Products(105, 'Iphone 15 Pro', 'Popular choice with dual cameras', '128 GB', 50000, 4, './assets/iphone16.jpg'),
     new Products(106, 'Iphone 16 Pro', 'Premium model with Pro features', '256 GB', 100000, 1, './assets/iphone16Pro.jpg')
      ];;
   }
   addProductsItem(ProductsObj:Products)
   {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr);
   }
   getAllProductsItems(){
    return this.productsArr;
   }
   deleteProductsItem(productId:number)
   {
    var pos = this.productsArr.findIndex(item=> item.productId == productId)
    if(pos>=0)
    {
      this.productsArr.splice(pos,1);
      return productId;
    }
    else 
      return productId;
   }

}
