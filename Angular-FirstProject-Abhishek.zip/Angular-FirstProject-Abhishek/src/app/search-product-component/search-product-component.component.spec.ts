import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchProductComponentComponent } from './search-product-component.component';

describe('SearchProductComponentComponent', () => {
  let component: SearchProductComponentComponent;
  let fixture: ComponentFixture<SearchProductComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SearchProductComponentComponent]
    });
    fixture = TestBed.createComponent(SearchProductComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
