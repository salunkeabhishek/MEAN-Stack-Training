import { Component, inject } from '@angular/core';
import Products from '../model/Products';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-search-product-component',
  templateUrl: './search-product-component.component.html',
  styleUrls: ['./search-product-component.component.css']
})
export class SearchProductComponentComponent {
     productArr: Products[];
     searchText: string;
     fieldNameArr: any[];
     fieldName:string;
     selectedProduct:Products|null;
     productManagementService : ProductManagementService;
     constructor(){
      this.searchText ="";
      this.fieldName="";
      this.selectedProduct=null;
      this.fieldNameArr=[
          {name:"Product Name",value:"productName"},
          {name:"Product Id",value:"productId"},
          {name:"Price",value:"price"},
          {name:"Quantity",value:"quantity"}
     ];
      this.productManagementService = inject(ProductManagementService);
      this.productArr = this.productManagementService.getAllProductsItems();
     }

     searchTextOnClick(searchText:string, fieldName:string){
          this.searchText = searchText;
          this.fieldName = fieldName;
     }
     editEventHandler(subProuct:Products){
               this.selectedProduct=subProuct;
     }
     clearSearchBox(input: HTMLInputElement){
          input.value = '';
          this.searchTextOnClick('','');
     }
}
