import { Component, ViewEncapsulation } from '@angular/core';
import { FooterComponent } from "./footer/footer.component";
import { HeaderComponent } from "./header/header.component";

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.Emulated // None - apply for all component , Emulated only for this component, Shadow for all child
})
export class AppComponent {
  title = 'first-project';
  company:string;
  empObj:any;
  empObj1:object;
  birthDay1:string;
  constructor(){
    this.company="MMC";
    this.empObj ={empId:1234,empName:"abhishek Salunke"};
    this.empObj1 = {empId:48949,empName:"abhishek Salunke",empDOB:"18/09/2034"};
    this.birthDay1="12/02/2025";
  }

}
