import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { SearchProductComponentComponent } from './search-product-component/search-product-component.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { RegisterModelComponent } from './register-model/register-model.component';
import { CartComponent } from './cart/cart.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
 
const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"products",component:ProductDisplayComponent},
  {path:"searchProduct", component:SearchProductComponentComponent},
  {path:"payments",component:PaymentsComponent,
    children:[
      {path:"card",component:PaymentByCardComponent},
      {path:"wallet",component:PaymentByWalletComponent},
      {path:"upi",component:PaymentByUPIComponent},
      {path:"",component:PaymentByCardComponent},
      {path:"netbanking",component:PaymentByNetBankingComponent}
    ]
  },
  {path:"productDetails/:productId",component:ProductDetailsComponent},
  {path:"login",component:RegisterModelComponent},
  {path:"cart",component:CartComponent},
  {path:"newUser",component:UserRegistrationComponent},
  {path:"",redirectTo:"home",pathMatch:"full"},
  {path:"**",component:PageNotFoundComponent}
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }