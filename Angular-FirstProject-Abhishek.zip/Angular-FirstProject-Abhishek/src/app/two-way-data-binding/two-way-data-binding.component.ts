import { Component } from '@angular/core';

@Component({
  selector: 'app-two-way-data-binding',
  templateUrl: './two-way-data-binding.component.html',
  styleUrls: ['./two-way-data-binding.component.css']
})
export class TwoWayDataBindingComponent {
    countryName:string;
    personName:string;
    constructor(){
      this.countryName ="=India";
      this.personName ="Sudarshan"
    }
    inputEventhandler(event:any)
    {
        console.log("Value type", event.target.value);
        this.countryName = event.target.value;
    }
}
