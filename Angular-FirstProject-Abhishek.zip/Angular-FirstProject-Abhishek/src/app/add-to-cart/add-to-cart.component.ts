import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import Products from '../model/Products';
import Cart from '../model/Cart';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnChanges, OnInit{
quantitySelected:number;
cartObj: Cart|null;
@Input("selProduct") product: Products|null;
@Output() sendDataFromAddToCartToPD:EventEmitter<Cart|null>;
sendCancelDataFromAddToCartToPD:EventEmitter<any>;
constructor( private cartManagementService: CartManagementService){
  this.product=null;
  this.quantitySelected =1;
  this.sendDataFromAddToCartToPD = new EventEmitter<Cart| null>();
  this.sendCancelDataFromAddToCartToPD = new EventEmitter<any>;
  this.cartObj =null;

}

ngOnInit(): void {
    console.log("NgOnInit is triggered");
}
ngOnChanges(changes: SimpleChanges): void {
   console.log("NgOnchanges is add to cart added");
   console.log("Changes", changes) 
   if(changes['product'].previousValue && changes['product'].currentValue.productId !== changes['product'].previousValue.productId)
   {
    this.quantitySelected=1;
   }
}
modifyQuantity(op:string){
  if(op=="dec"){
       if(this.quantitySelected>1)
       {
        --this.quantitySelected;
       }
  }
  else {
          if(this.product && this.product.quantity > this.quantitySelected)
            ++this.quantitySelected;
  }
}
confirmEvetHandler(){
 this.cartObj = this.product ? new Cart(this.product.productId,this.product.productName,this.product.description,this.product.storage,this.product.price,this.product.quantity,this.product.imageUrl,this.quantitySelected): null;
 this.sendDataFromAddToCartToPD.emit(this.cartObj);
 if(this.cartObj){
  this.cartManagementService.addCartItem(this.cartObj);
 }
}
cancelEvetHandler(){
this.sendCancelDataFromAddToCartToPD.emit();
}

ngOnDestroy(){
  if (this.cartObj) {
    alert("Items added to the cart with productId " + this.product?.productId);
  }
  else {
    alert("Sorry to see u go !!!!");
  }
  }
}
