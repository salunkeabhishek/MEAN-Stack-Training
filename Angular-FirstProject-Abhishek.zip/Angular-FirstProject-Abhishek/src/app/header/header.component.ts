import { Component, inject, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
}
