export default class Products{
    productId:number;
    productName:string;
    description:string;
    storage:string;
    price: number;
    quantity:number;
    imageUrl:string;
    constructor(productId:number,productName:string,description:string,storage:string,price:number,quantity:number,imageUrl:string){
            this.productId = productId;
            this.productName = productName;
            this.description = description;
            this.storage = storage;
            this.price = price;
            this.quantity = quantity;
            this.imageUrl = imageUrl;
        
    }
}