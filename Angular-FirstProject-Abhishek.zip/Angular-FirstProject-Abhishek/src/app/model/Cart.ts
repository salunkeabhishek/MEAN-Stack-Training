import Products from './Products';

class Cart extends Products {
    quantitySelected:number;
    constructor(productId:number,productName:string,description:string,storage:string,price:number,quantity:number,imageUrl:string,quatitySelected:number){
        super(productId,productName,description,storage,price,quantity,imageUrl);
        this.quantitySelected = quatitySelected;
    }
}
export default Cart;
