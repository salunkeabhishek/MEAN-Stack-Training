import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-net-banking',
  templateUrl: './payment-by-net-banking.component.html',
  styleUrls: ['./payment-by-net-banking.component.css']
})
export class PaymentByNetBankingComponent {

}
